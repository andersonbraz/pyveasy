# Python VSCode Easy

Library create a Python project tuned for VSCode.

## Install library

```
$ pip3 install pyveasy
```

## Requeriments 

Add content on ~/.zshrc or ~/.bashrc

```python
# PYTHON
export PYTHON3_HOME=~/Library/Python/3.8/
export PATH=$PATH:$PYTHON3_HOME/bin
```

Execute command and follow step-by-step

```
$ pyveasy
```
